                    </div>
                </div>
            </div>
        </div>
        <footer class="footer footer-alt">
            © 2019 - <?=date('Y') ?> FreeGen. Tous droits réservés.
        </footer>
        <script src="/assets/js/vendor.min.js"></script>
        <script src="/assets/js/app.min.js"></script>
        <script src="/assets/js/script.js"></script>
        <script src="https://www.google.com/recaptcha/api.js"></script>
    </body>
</html>
</html>