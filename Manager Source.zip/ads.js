var e = document.createElement('div');
e.classList.add = '25fvgfdgfd';
e.style.display = 'none';
document.body.appendChild(e);