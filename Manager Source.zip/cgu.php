<?php
require('inc/fonctions.php');

$title = 'CGU';
require('inc/header_auth.php');
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="text-center">
                <h3 class="mb-2">#1 - Condition d'utilisation</h3>
                <p class="text-muted w-50 m-auto">
                    Ceed#2117 et bg !
                </p>
            </div>
<?php require('inc/footer_auth.php'); ?>